[build-menu]
FT_00_LB=_Compile
FT_00_CM=cppc "%f"
FT_00_WD=
FT_01_LB=_Build
FT_01_CM=cppc -d "%d"
FT_01_WD=
