[build-menu]
FT_00_LB=_Compile
FT_00_CM=javac "%f" -d .
FT_00_WD=
